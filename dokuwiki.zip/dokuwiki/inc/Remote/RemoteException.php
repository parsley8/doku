<?php

namespace dokuwiki\Remote;

/**
 * Class RemoteException
 */
class RemoteException extends \Exception
{
}
