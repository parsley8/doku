<?php
\dokuwiki\Debug\DebugHelper::dbgDeprecatedFunction(
    'Autoloading', 1, 'require(' . basename(__FILE__) . ')'
);
